const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const postsRoutes = require("./routes/posts");
const userRoutes = require("./routes/user");
const adminRoutes = require("./routes/admin");
const teacherRoutes = require("./routes/teacher");

const app = express();

mongoose
  .connect(
    "mongodb+srv://adminUser:nf6x6Hj1xjM9aBoY@cluster0.ngu0t.mongodb.net/login?retryWrites=true&w=majority",{useCreateIndex:true, useNewUrlParser: true, useUnifiedTopology: true,}
    // "mongodb+srv://adminUser:FepkO5JC6sG8HzsB@cluster0.ngu0t.mongodb.net/foodorder?retryWrites=true&w=majority"
  )
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use("/images", express.static(path.join("backend/images")));

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PATCH, PUT, DELETE, OPTIONS"
  );
  next();
});

app.use("/api/posts", postsRoutes);
app.use("/api/user", userRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/teacher", teacherRoutes);

const port = 3000;

app.listen(port,() => {
  console.log(`server running on port ${port}`);
})
