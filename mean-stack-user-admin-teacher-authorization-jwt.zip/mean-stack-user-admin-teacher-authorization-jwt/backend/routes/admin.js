const express = require("express");
// const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const Admin = require("../models/admin");

const router = express.Router();

router.post("/signup", (req, res, next) => {
  const admin = new Admin({
    email: req.body.email,
    password: req.body.password,
  });
  admin
    .save()
    .then(result => {
      res.status(201).json({
        message: "Admin created!",
        result: result
      });
    })
    .catch(err => {
      res.status(500).json({
        error: err
      });
    });

});

router.post("/login", async (req, res, next) => {

  let a = await Admin.findOne({ email: req.body.email })
  const adminToken = jwt.sign(
    { email: a.email, userId: a._id },
    "secret_this_should_be_longer",
    { expiresIn: "1m" }
  );
  res.status(200).json({
    adminToken: adminToken,
    expiresIn: 60
  });
});

module.exports = router;
