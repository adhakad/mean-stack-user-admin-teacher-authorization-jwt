const express = require("express");
// const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const Teacher = require("../models/teacher");

const router = express.Router();

router.post("/signup", (req, res, next) => {
  const teacher = new Teacher({
    email: req.body.email,
    password: req.body.password,
  });
  teacher
    .save()
    .then(result => {
      res.status(201).json({
        message: "Teacher created!",
        result: result
      });
    })
    .catch(err => {
      res.status(500).json({
        error: err
      });
    });

});

router.post("/login", async (req, res, next) => {

  let a = await Teacher.findOne({ email: req.body.email })
  const token = jwt.sign(
    { email: a.email, userId: a._id },
    "secret_this_should_be_longer",
    { expiresIn: "1m" }
  );
  res.status(200).json({
    token: token,
    expiresIn: 60
  });
});

module.exports = router;
