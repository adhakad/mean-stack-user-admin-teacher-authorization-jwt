import { Component } from "@angular/core";
import { NgForm } from "@angular/forms";

import { TeacherAuthService } from "../teacher-auth.service";
@Component({
  selector: 'app-teacher-signup',
  templateUrl: './teacher-signup.component.html',
  styleUrls: ['./teacher-signup.component.css']
})
export class TeacherSignupComponent {
  isLoading = false;

  constructor(public authService: TeacherAuthService) {}

  onSignup(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    this.authService.createUser(form.value.email, form.value.password);
  }
}
