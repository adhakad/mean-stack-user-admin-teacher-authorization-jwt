import { Component} from '@angular/core';
import { NgForm } from "@angular/forms";

import { TeacherAuthService } from '../teacher-auth.service';
@Component({
  selector: 'app-teacher-login',
  templateUrl: './teacher-login.component.html',
  styleUrls: ['./teacher-login.component.css']
})
export class TeacherLoginComponent {

  isLoading = false;

  constructor(public authService: TeacherAuthService) {}

  onLogin(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    this.authService.login(form.value.email, form.value.password);
  }

}
