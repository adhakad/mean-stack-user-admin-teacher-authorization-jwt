import { Component, OnInit, OnDestroy } from "@angular/core";
import { Subscription } from "rxjs";
import { AdminAuthService } from "../admin-auth/admin-auth.service";

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit, OnDestroy {
  adminIsAuthenticated = false;
  private authListenerSubs: Subscription;

  constructor(private adminService: AdminAuthService) {}

  ngOnInit() {
    this.adminService.autoAuthAdmin();
    this.adminIsAuthenticated = this.adminService.getIsAdminAuth();
    this.authListenerSubs = this.adminService
      .getauthAdminStatusListener()
      .subscribe(isAuthenticated => {
        this.adminIsAuthenticated = isAuthenticated;
      });
  }

  onLogout() {
    this.adminService.logout();
  }

  ngOnDestroy() {
    this.authListenerSubs.unsubscribe();
  }
}
