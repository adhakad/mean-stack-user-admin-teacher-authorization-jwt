export interface authAdminData {
    email: string;
    password: string;
  }
  