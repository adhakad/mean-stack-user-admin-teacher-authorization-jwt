import { Component } from '@angular/core';
import { NgForm } from "@angular/forms";

import { AdminAuthService } from '../admin-auth.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {

  isLoading = false;

  constructor(public adminService: AdminAuthService) {}

  onLogin(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    this.adminService.login(form.value.email, form.value.password);
  }
}
