import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { Subject } from "rxjs";

import { authAdminData } from './admin-auth-data.model';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthService {
  private isAdminAuthenticated = false;
  private adminToken: string;
  private adminTokenTimer: any;
  private authAdminStatusListener = new Subject<boolean>();

  constructor(private http: HttpClient, private router: Router) { }

  getAdminToken() {
    return this.adminToken;
  }

  getIsAdminAuth() {
    return this.isAdminAuthenticated;
  }

  getauthAdminStatusListener() {
    return this.authAdminStatusListener.asObservable();
  }

  createAdmin(email: string, password: string) {
    const authAdminData: authAdminData = { email: email, password: password };
    this.http
      .post("http://localhost:3000/api/admin/signup", authAdminData)
      .subscribe(response => {
        console.log(response);
      });
  }

  login(email: string, password: string) {
    const authAdminData: authAdminData = { email: email, password: password };
    this.http
      .post<{ adminToken: string; expiresIn: number }>(
        "http://localhost:3000/api/admin/login",
        authAdminData
      )
      .subscribe(response => {
        const adminToken = response.adminToken;
        this.adminToken = adminToken;
        if (adminToken) {
          const expiresInDuration = response.expiresIn;
          this.setAuthTimer(expiresInDuration);
          this.isAdminAuthenticated = true;
          this.authAdminStatusListener.next(true);
          const now = new Date();
          const expirationDate = new Date(now.getTime() + expiresInDuration * 1000);
          // console.log(expirationDate);
          this.saveAuthAdminData(adminToken, expirationDate);
          this.router.navigate(["/admin"]);
        }
      });
  }

  autoAuthAdmin() {
    const authAdminInformation = this.getAuthAdminData();
    if (!authAdminInformation) {
      return;
    }
    const now = new Date();
    const expiresIn = authAdminInformation.expirationDate.getTime() - now.getTime();
    if (expiresIn > 0) {
      this.adminToken = authAdminInformation.adminToken;
      this.isAdminAuthenticated = true;
      this.setAuthTimer(expiresIn / 1000);
      this.authAdminStatusListener.next(true);
    }
  }

  logout() {
    this.adminToken = null;
    this.isAdminAuthenticated = false;
    this.authAdminStatusListener.next(false);
    clearTimeout(this.adminTokenTimer);
    this.clearAuthAdminData();
    this.router.navigate(["/admin-login"]);
  }

  private setAuthTimer(duration: number) {
    // console.log("Setting timer: " + duration);
    this.adminTokenTimer = setTimeout(() => {
      this.logout();
    }, duration * 1000);
  }

  private saveAuthAdminData(adminToken: string, expirationDate: Date) {
    localStorage.setItem("adminToken", adminToken);
    localStorage.setItem("adminExpiration", expirationDate.toISOString());
  }

  private clearAuthAdminData() {
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminExpiration");
  }

  private getAuthAdminData() {
    const adminToken = localStorage.getItem("adminToken");
    const expirationDate = localStorage.getItem("adminExpiration");
    if (!adminToken || !expirationDate) {
      return;
    }
    return {
      adminToken: adminToken,
      expirationDate: new Date(expirationDate)
    }
  }
}
