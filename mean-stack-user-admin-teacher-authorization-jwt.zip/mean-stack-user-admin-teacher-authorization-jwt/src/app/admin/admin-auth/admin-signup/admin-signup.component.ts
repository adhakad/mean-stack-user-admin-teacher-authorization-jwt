import { Component } from '@angular/core';
import { NgForm } from "@angular/forms";
import { AdminAuthService } from '../admin-auth.service';

@Component({
  selector: 'app-admin-signup',
  templateUrl: './admin-signup.component.html',
  styleUrls: ['./admin-signup.component.css']
})
export class AdminSignupComponent {
  isLoading = false;

  constructor(public adminService:AdminAuthService) { }

  onSignup(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    this.adminService.createAdmin(form.value.email, form.value.password);
  }

}
