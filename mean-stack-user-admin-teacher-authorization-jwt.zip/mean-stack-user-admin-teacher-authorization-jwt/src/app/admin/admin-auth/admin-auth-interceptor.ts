import {
    HttpInterceptor,
    HttpRequest,
    HttpHandler
  } from "@angular/common/http";
  import { Injectable } from "@angular/core";
  
  import { AdminAuthService } from "./admin-auth.service";
  
  @Injectable()
  export class AuthInterceptor implements HttpInterceptor {
    constructor(private adminService: AdminAuthService) {}
  
    intercept(req: HttpRequest<any>, next: HttpHandler) {
      const authToken = this.adminService.getAdminToken();
      const authRequest = req.clone({
        headers: req.headers.set("Authorization", "Bearer " + authToken)
      });
      return next.handle(authRequest);
    }
  }
  