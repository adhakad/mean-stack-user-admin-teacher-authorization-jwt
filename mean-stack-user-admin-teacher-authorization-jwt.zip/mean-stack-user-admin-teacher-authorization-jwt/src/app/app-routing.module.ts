import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { PostListComponent } from "./posts/post-list/post-list.component";
import { PostCreateComponent } from "./posts/post-create/post-create.component";
import { LoginComponent } from "./auth/login/login.component";
import { SignupComponent } from "./auth/signup/signup.component";
import { AuthGuard } from "./auth/auth.guard";
import { AdminSignupComponent } from "./admin/admin-auth/admin-signup/admin-signup.component";
import { AdminLoginComponent } from "./admin/admin-auth/admin-login/admin-login.component";
import { AdminListComponent } from "./admin/admin-list/admin-list.component";
import { AdminComponent } from "./admin/admin/admin.component";
import { AdminAuthGuardGuard } from "./admin/admin-auth/admin-auth-guard.guard";
import { TeacherComponent } from "./teacher/teacher/teacher.component";
import { TeacherLoginComponent } from "./teacher/teacher-auth/teacher-login/teacher-login.component";
import { TeacherSignupComponent } from "./teacher/teacher-auth/teacher-signup/teacher-signup.component";
import { TeacherAuthGuard } from "./teacher/teacher-auth/teacher-auth.guard";
import { TeacherListComponent } from "./teacher/teacher-list/teacher-list.component";

const routes: Routes = [
  { path: '', redirectTo: 'post-list', pathMatch: 'full' },
  { path: 'post-list', component: PostListComponent },
  { path: "create", component: PostCreateComponent, canActivate: [AuthGuard] },
  { path: "edit/:postId", component: PostCreateComponent, canActivate: [AuthGuard] },
  { path: "login", component: LoginComponent },
  { path: "signup", component: SignupComponent },

// admin section
  { path: "admin", component: AdminComponent },
  { path: "admin-list", component: AdminListComponent ,canActivate: [AdminAuthGuardGuard]},
  { path: "admin-login", component: AdminLoginComponent },
  { path: "admin-signup", component: AdminSignupComponent },

  // teacher section
  { path: "teacher", component: TeacherComponent },
  { path: "teacher-list", component: TeacherListComponent ,canActivate: [TeacherAuthGuard]},
  { path: "teacher-login", component: TeacherLoginComponent },
  { path: "teacher-signup", component: TeacherSignupComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard]
})
export class AppRoutingModule {}
